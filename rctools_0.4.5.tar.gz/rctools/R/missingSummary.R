#### Intended for use with the `redcapAPI` package
#' @name missingSummary
#' @aliases missingSummary.redcapApiConnection
#' @aliases missingSummary.redcapDbConneciton
#' @aliases missingSummary_offline
#'
#' @title Report of Missing Values
#' @description Returns a data frame of subject events with missing values.
#'
#' @param url A url address to connect to the REDCap API
#' @param token A REDCap API token
#' @param proj A redcapProjectInfo object.
#' @param batch.size Batch size parameter for \code{rc_export}
#' @param records a filename pointing to the raw records download from REDCap
#' @param data_dict a filename pointing to the data data_dictionary download from REDCap
#' @param excludeMissingForms If all of the fields in a form are missing, would
#'   you like to assume that they are purposefully missing?  For instance, if
#'   a patient did not experience an adverse event, the adverse event form would
#'   contain no data and you would not want it in this report.
#' @param ... Additional arguments to pass to other methods.  Currently ignored.
#'
#' @details The intention of this function is to generate a list of subject
#'   events that are missing and could potentially be values that should have
#'   been entered.
#'
#'   The branching logic from the data data_dictionary is parsed and translated into
#'   and R expression.  When a field with branching logic passes the logical
#'   statement, it is evaluated with \code{is.na}, otherwise, it is set to
#'   \code{FALSE} (non-missing, because there was never an opportunity to
#'   provide a value).
#'
#'   Optionally, forms that are entirely missing can be determined to be
#'   non-missing.  This is applicable when, for instance, a patient did not
#'   have an adverse event.  In this case, a form dedicated to adverse events
#'   would contain meaningless missing values and could be excluded from the
#'   report.
#'
#' @author Benjamin Nutter
#'

missingSummary <- function(url = getOption("redcap_bundle")$redcap_url,
token = getOption("redcap_token"),

                                 excludeMissingForms = TRUE, ...,
                                 proj=NULL, batch.size=-1){

  records <- rc_export(url, token, factors=FALSE, labels=TRUE,
                           dates=FALSE, survey=FALSE, dag=TRUE,
                           batch.size=batch.size)
  #   records.orig <- records

  data_dict <- exportMetaData(url, token)
  data_dict <- data_dict[data_dict$field_type != "descriptive", ]

  form_names <- unique(data_dict$form_name)
  form_complete_names <- paste0(form_names, "_complete")

  logic <- parseBranchingLogic(data_dict$branching_logic)
  names(logic) <- data_dict$field_name

  start_value <- 2 + sum(c("redcap_event_name", "redcap_data_access_group") %in% names(records))
  for (i in utils::tail(seq_along(records), -(start_value - 1))){

    l <- logic[[names(records)[i]]]

    tmp_form <- data_dict$form_name[data_dict$field_name ==
                                      sub("___[[:print:]]", "", names(records)[i])]

    tmp_form <- paste0(tmp_form, "_complete")

    {
      if (tmp_form == "_complete") records[[i]] <- FALSE
      if (!tmp_form %in% names(records))
        records[[i]] <- is.na(records[[i]])
      else if (!is.expression(l))
        records[[i]] <- ifelse(is.na(records[[tmp_form]]),
                               FALSE, is.na(records[[i]]))
      else
        records[[i]] <- ifelse(is.na(records[['visit_data_complete']]),
                               FALSE,
                               ifelse(with(records, eval(l)), is.na(records[[i]]),
                                      FALSE))
    }
  }

  if (excludeMissingForms){
    for (i in seq_len(nrow(records))){
      completeFormMissing <- lapply(form_names,
                                    function(f){
                                      flds <- data_dict$field_name[data_dict$form_name %in% f]
                                      flds <- flds[!flds %in% data_dict$field_name[1]]
                                      flds <- flds[!flds %in% data_dict$field_name[data_dict$field_type == "checkbox"]]
                                      if (all(unlist(records[i, flds, drop=FALSE]) | sapply(logic[flds], is.expression))){
                                        return(flds)
                                      }
                                      else return(NULL)
                                    })
      completeFormMissing <- unlist(completeFormMissing)
      if (!is.null(completeFormMissing)) records[i, completeFormMissing] <- FALSE
    }
  }

  n_missing <- apply(records[-(1:(start_value-1))], 1, sum)

  missing <- apply(records[-(1:(start_value-1))], 1,
                   function(r) paste(names(r)[r], collapse=", "))

  MissingReport <-
    cbind(records[, 1:(start_value - 1)],
          n_missing,
          missing)

  return(MissingReport)
}

#' @rdname missingSummary
#'

missingSummary_offline <- function(records, data_dict,
                                   excludeMissingForms = TRUE){

  records <- utils::read.csv(records,
                      stringsAsFactors=FALSE,
                      na.string="")
  #   records.orig <- records

  data_dict <- utils::read.csv(data_dict,
                        col.names=c('field_name', 'form_name', 'section_header',
                                    'field_type', 'field_label', 'select_choices_or_calculations',
                                    'field_note', 'text_validation_type_or_show_slider_number',
                                    'text_validation_min', 'text_validation_max', 'identifier',
                                    'branching_logic', 'required_field', 'custom_alignment',
                                    'question_number', 'matrix_group_name', 'matrix_ranking',
                                    'field_annotation'),
                        stringsAsFactors=FALSE)
  data_dict <- data_dict[data_dict$field_type != "descriptive", ]

  form_names <- unique(data_dict$form_name)
  form_complete_names <- paste0(form_names, "_complete")

  logic <- parseBranchingLogic(data_dict$branching_logic)
  names(logic) <- data_dict$field_name

  start_value <- 2 + sum(c("redcap_event_name", "redcap_data_access_group") %in% names(records))
  for (i in utils::tail(seq_along(records), -(start_value - 1))){
    l <- logic[[names(records)[i]]]

    tmp_form <- data_dict$form_name[data_dict$field_name ==
                                      sub("___[[:print:]]", "", names(records)[i])]
    tmp_form <- paste0(tmp_form, "_complete")

    {if (tmp_form == "_complete") records[[i]] <- FALSE
      else if (!is.expression(l))
        records[[i]] <- ifelse(is.na(records[[tmp_form]]),
                               FALSE, is.na(records[[i]]))
      else
        records[[i]] <- ifelse(is.na(records[[tmp_form]]),
                               FALSE,
                               ifelse(with(records, eval(l)), is.na(records[[i]]),
                                      FALSE))
    }
  }

  if (excludeMissingForms){
    for (i in seq_len(nrow(records))){
      completeFormMissing <- lapply(form_names,
                                    function(f){
                                      flds <- data_dict$field_name[data_dict$form_name %in% f]
                                      flds <- flds[!flds %in% data_dict$field_name[1]]
                                      flds <- flds[!flds %in% data_dict$field_name[data_dict$field_type == "checkbox"]]
                                      if (all(unlist(records[i, flds, drop=FALSE]) | sapply(logic[flds], is.expression))){
                                        return(flds)
                                      }
                                      else return(NULL)
                                    })
      completeFormMissing <- unlist(completeFormMissing)
      if (!is.null(completeFormMissing)) records[i, completeFormMissing] <- FALSE
    }
  }

  n_missing <- apply(records[-(1:(start_value-1))], 1, sum)

  missing <- apply(records[-(1:(start_value-1))], 1,
                   function(r) paste(names(r)[r], collapse=", "))

  MissingReport <-
    cbind(records[, 1:(start_value - 1)],
          n_missing,
          missing)

  return(MissingReport)
}
